# Zainab Assignment Work website

## Included
- Responsive luxury-minimal design
- English / Urdu language switch
- Application form: name, age (18+), qualification, city, active WhatsApp number
- WhatsApp button appears only after valid form submission
- Clicking WhatsApp opens a pre-filled message to 92323687923
- Form details are not sent to a server; they are passed to WhatsApp only after the visitor clicks the WhatsApp button

## Publish on Cloudflare Pages using a phone
1. Create/sign in to GitHub: https://github.com
2. Create a new public repository, for example `zainab-assignment-work`.
3. Upload `index.html` from this folder to the repository root.
4. Sign in to https://dash.cloudflare.com
5. Open Workers & Pages > Create application > Pages > Connect to Git.
6. Select the GitHub repository.
7. For a plain HTML site, leave the framework preset as None. Set the build command empty and the output directory to `/` (or use the direct upload option and upload the site folder).
8. Deploy. Cloudflare will provide a `*.pages.dev` address.

## Important
This is a static information/application page, not proof that paid assignments are currently available. Before publishing, make sure the work, eligibility, payment rates, deadlines, review policy and business identity are accurate. Do not claim guaranteed income or collect any fee from applicants unless it is lawful, transparent and genuinely necessary. Consider adding a real business name and privacy contact before collecting applications.
